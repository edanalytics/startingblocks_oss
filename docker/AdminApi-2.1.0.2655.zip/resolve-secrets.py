import boto3
import json
import os

env_label = os.environ.get('ENV_LABEL')
client = boto3.client('secretsmanager')
response = client.get_secret_value(SecretId=os.environ['AURORA_MASTER_SECRET'])
secret = json.loads(response['SecretString'])
response = client.get_secret_value(SecretId=os.environ['ADMIN_API_SECRET'])
adminApiSecret = response['SecretString']

password = secret['password']
username = secret['username']
host = secret['host']
port = secret['port']

with open('/app/appsettings.json', 'r') as f:
    appsettings = json.load(f)

appsettings['Authentication']['SigningKey'] = adminApiSecret

if os.environ.get('MULTI_TENANCY') == 'true':
    # get tenants from dynamodb
    tenants = []
    client = boto3.client('dynamodb')
    paginator = client.get_paginator('scan')
    response_iterator = paginator.paginate(
        TableName=f'{env_label}-tenants'
    )
    for page in response_iterator:
        for item in page['Items']:
            print(item['Name']['S'].lower())
            tenants.append(
                dict(
                    Name = item['Name']['S'].lower()
                )
            )

    # tenants=[{'Name': 'test1'}, {'Name': 'test2'}]
    
    if 'ConnectionStrings' in appsettings:
        appsettings.pop('ConnectionStrings')   

    # set first level
    appsettings['Tenants'] = {}
    for tenant in tenants:
        appsettings['Tenants'][tenant['Name']] = {}
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings'] = {}
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings']['EdFi_Security'] = f'host={host};port={port};username={username};password={password};database=security_{tenant["Name"]};Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;'
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings']['EdFi_Admin'] = f'host={host};port={port};username={username};password={password};database=admin_{tenant["Name"]};Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;'

else:
    appsettings['ConnectionStrings']['EdFi_Security'] = f'host={host};port={port};username={username};password={password};database=security_default;Application Name=EdFi.Ods.AdminApp;SSL Mode=Require;Trust Server Certificate=true'
    appsettings['ConnectionStrings']['EdFi_Admin'] = f'host={host};port={port};username={username};password={password};database=admin_default;Application Name=EdFi.Ods.AdminApp;SSL Mode=Require;Trust Server Certificate=true'


with open('/app/appsettings.json', 'w') as f:
   f.write(json.dumps(appsettings, indent=4))

# with open('/root/.pgpass', 'w') as f:
#     f.write(f'{host}:{port}:*:{username}:{password}')

# os.chmod('/root/.pgpass', 0o600)


