import boto3
import json
import os

env_label = os.environ.get('ENV_LABEL')
max_pool_size = os.environ.get('MAX_POOL_SIZE')
connection_idle_lifetime = os.environ.get('CONNECTION_IDLE_LIFETIME')
aurora_master_secret = os.environ.get('AURORA_MASTER_SECRET')

client = boto3.client('secretsmanager')
response = client.get_secret_value(SecretId=aurora_master_secret)
secret = json.loads(response['SecretString'])

password = secret['password']
username = secret['username']
host = secret['host']
port = secret['port']

response = client.get_secret_value(SecretId=f'{env_label}-WebApiSecret')
enc_key = response['SecretString']

with open('/app/appsettings.json', 'r') as f:
    appsettings = json.load(f)

appsettings['ApiSettings']['OdsConnectionStringEncryptionKey'] = enc_key

if os.environ.get('MULTI_TENANCY') == 'true':
    # get tenants from dynamodb
    tenants = []
    client = boto3.client('dynamodb')
    paginator = client.get_paginator('scan')
    response_iterator = paginator.paginate(
        TableName=f'{env_label}-tenants'
    )
    for page in response_iterator:
        for item in page['Items']:
            print(item['Name']['S'].lower())
            tenants.append(
                dict(
                    Name = item['Name']['S'].lower()
                )
            )

    # tenants=[{'Name': 'test1'}, {'Name': 'test2'}]
    
    if 'ConnectionStrings' in appsettings:
        appsettings.pop('ConnectionStrings')   

    # set first level
    appsettings['Tenants'] = {}
    for tenant in tenants:
        appsettings['Tenants'][tenant['Name']] = {}
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings'] = {}
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings']['EdFi_Security'] = f'host={host};port={port};username={username};password={password};database=security_{tenant["Name"]};Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;Maximum Pool Size={max_pool_size};Connection Idle Lifetime={connection_idle_lifetime};'
        appsettings['Tenants'][tenant['Name']]['ConnectionStrings']['EdFi_Admin'] = f'host={host};port={port};username={username};password={password};database=admin_{tenant["Name"]};Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;Maximum Pool Size={max_pool_size};Connection Idle Lifetime={connection_idle_lifetime};'

else:
    appsettings['ConnectionStrings']['EdFi_Security'] = f'host={host};port={port};username={username};password={password};database=security_default;Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;Maximum Pool Size={max_pool_size};Connection Idle Lifetime={connection_idle_lifetime};'
    appsettings['ConnectionStrings']['EdFi_Admin'] = f'host={host};port={port};username={username};password={password};database=admin_default;Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;Maximum Pool Size={max_pool_size};Connection Idle Lifetime={connection_idle_lifetime};'
    appsettings['ConnectionStrings']['EdFi_Master'] = f'host={host};port={port};username={username};password={password};database=postgres;Application Name=EdFi.Ods.WebApi;SSL Mode=Require;Trust Server Certificate=true;Maximum Pool Size={max_pool_size};Connection Idle Lifetime={connection_idle_lifetime};'

with open('/app/appsettings.json', 'w') as f:
   f.write(json.dumps(appsettings, indent=4))
